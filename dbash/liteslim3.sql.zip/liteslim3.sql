-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 11, 2017 at 05:25 PM
-- Server version: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flexiplanrevamp`
--

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE `contents` (
  `id` int(11) NOT NULL,
  `title` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `msisdn` varchar(15) NOT NULL,
  `imei` varchar(50) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `msisdn`, `imei`, `status`, `created_at`, `updated_at`) VALUES
(1, '01712255555', 'IME0010009EVL', '1', '2017-11-23 06:26:55', '2017-11-23 06:26:55'),
(2, '01712255555', 'IME0010009EVL', '1', '2017-11-23 06:36:33', '2017-11-23 06:36:33'),
(3, '01712255555', 'IME0010009EVL', '1', '2017-11-23 06:44:07', '2017-11-23 06:44:07'),
(4, '01712255555', 'IME0010009EVL', '1', '2017-11-23 06:47:54', '2017-11-23 06:47:54'),
(5, '01712256666', 'IME0010009EVL', '1', '2017-11-23 06:49:03', '2017-11-23 06:49:03'),
(6, '01712337579', 'IME0010009EVL', '1', '2017-11-29 10:17:31', '2017-11-29 10:17:31'),
(7, '01712337571', 'IME0010009EVL', '1', '2017-11-29 10:19:05', '2017-11-29 10:19:05'),
(8, '01712337572', 'IME0010009EVL', '1', '2017-11-29 10:20:19', '2017-11-29 10:20:19'),
(9, '01712337573', 'IME0010009EVL', '1', '2017-11-29 10:23:49', '2017-11-29 10:23:49');

-- --------------------------------------------------------

--
-- Table structure for table `flexiplanOptions`
--

CREATE TABLE `flexiplanOptions` (
  `id` int(11) NOT NULL,
  `option_type` varchar(255) NOT NULL,
  `option_value` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flexiplanOptions`
--

INSERT INTO `flexiplanOptions` (`id`, `option_type`, `option_value`, `status`, `created_at`, `updated_at`) VALUES
(1, 'data', '0', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(2, 'data', '20', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(3, 'data', '50', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(4, 'data', '100', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(5, 'data', '250', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(6, 'data', '500', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(7, 'data', '1536', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(8, 'data', '3072', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(9, 'data', '5120', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(10, 'voice', '0', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(11, 'voice', '10', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(12, 'voice', '25', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(13, 'voice', '50', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(14, 'voice', '100', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(15, 'voice', '300', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(16, 'voice', '500', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(17, 'voice', '1000', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(18, 'sms', '0', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(19, 'sms', '50', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(20, 'sms', '200', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(21, 'sms', '500', '1', '2017-11-16 08:06:02', '2017-11-16 08:06:02'),
(22, 'validity', '1', '1', '2017-11-16 08:06:03', '2017-11-16 08:06:03'),
(23, 'validity', '7', '1', '2017-11-16 08:06:03', '2017-11-16 08:06:03'),
(24, 'validity', '15', '1', '2017-11-16 08:06:03', '2017-11-16 08:06:03'),
(25, 'validity', '30', '1', '2017-11-16 08:06:03', '2017-11-16 08:06:03');

-- --------------------------------------------------------

--
-- Table structure for table `flexiplans`
--

CREATE TABLE `flexiplans` (
  `id` int(11) NOT NULL,
  `price_type` varchar(255) NOT NULL,
  `net_type` varchar(255) NOT NULL,
  `validity` smallint(3) NOT NULL,
  `mb_start` int(11) NOT NULL,
  `mb_end` int(11) DEFAULT NULL,
  `voice_start` int(11) NOT NULL,
  `voice_end` int(11) DEFAULT NULL,
  `price` float NOT NULL,
  `market_price` float NOT NULL,
  `status` enum('1','2','0') NOT NULL COMMENT '1=Inserted, 2=Updated, 0= To be Delete',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flexiplans`
--

INSERT INTO `flexiplans` (`id`, `price_type`, `net_type`, `validity`, `mb_start`, `mb_end`, `voice_start`, `voice_end`, `price`, `market_price`, `status`, `created_at`, `updated_at`) VALUES
(1, 'APPM', 'Onnet', 1, 0, 3, 0, 4, 0.36, 1.26, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(2, 'APPM', 'Onnet', 1, 0, 3, 5, 9, 0.36, 1.26, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(3, 'APPM', 'Onnet', 1, 0, 3, 10, 14, 0.36, 1.26, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(4, 'APPM', 'Onnet', 7, 0, 3, 0, 4, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(5, 'APPM', 'Onnet', 7, 0, 3, 5, 9, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(6, 'APPM', 'Onnet', 7, 0, 3, 10, 14, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(7, 'APPM', 'Onnet', 15, 0, 3, 0, 4, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(8, 'APPM', 'Onnet', 15, 0, 3, 5, 9, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(9, 'APPM', 'Onnet', 15, 0, 3, 10, 14, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(10, 'APPM', 'Onnet', 30, 0, 3, 0, 4, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(11, 'APPM', 'Onnet', 30, 0, 3, 5, 9, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(12, 'APPM', 'Onnet', 30, 0, 3, 10, 14, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(13, 'APPM', 'Anynet', 1, 0, 3, 0, 4, 0.36, 1.26, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(14, 'APPM', 'Anynet', 1, 0, 3, 5, 9, 0.36, 1.26, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(15, 'APPM', 'Anynet', 1, 0, 3, 10, 14, 0.36, 1.26, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(16, 'APPM', 'Anynet', 7, 0, 3, 0, 4, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(17, 'APPM', 'Anynet', 7, 0, 3, 5, 9, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(18, 'APPM', 'Anynet', 7, 0, 3, 10, 14, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(19, 'APPM', 'Anynet', 15, 0, 3, 0, 4, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(20, 'APPM', 'Anynet', 15, 0, 3, 5, 9, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(21, 'APPM', 'Anynet', 15, 0, 3, 10, 14, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(22, 'APPM', 'Anynet', 30, 0, 3, 0, 4, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(23, 'APPM', 'Anynet', 30, 0, 3, 5, 9, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(24, 'APPM', 'Anynet', 30, 0, 3, 10, 14, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(25, 'APPMB', 'Onnet', 1, 0, 3, 0, 4, 0.36, 1.26, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(26, 'APPMB', 'Onnet', 1, 0, 3, 5, 9, 0.36, 1.26, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(27, 'APPMB', 'Onnet', 1, 0, 3, 10, 14, 0.36, 1.26, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(28, 'APPMB', 'Onnet', 7, 0, 3, 0, 4, 0.35, 1.25, '2', '2017-11-22 06:06:01', '2017-11-22 06:06:39'),
(29, 'APPMB', 'Onnet', 7, 0, 3, 5, 9, 0.35, 1.25, '2', '2017-11-22 06:06:02', '2017-11-22 06:06:39'),
(30, 'APPMB', 'Onnet', 7, 0, 3, 10, 14, 0.35, 1.25, '2', '2017-11-22 06:06:02', '2017-11-22 06:06:40'),
(31, 'APPMB', 'Onnet', 15, 0, 3, 0, 4, 0.35, 1.25, '2', '2017-11-22 06:06:02', '2017-11-22 06:06:40'),
(32, 'APPMB', 'Onnet', 15, 0, 3, 5, 9, 0.35, 1.25, '2', '2017-11-22 06:06:02', '2017-11-22 06:06:40'),
(33, 'APPMB', 'Onnet', 15, 0, 3, 10, 14, 0.35, 1.25, '2', '2017-11-22 06:06:02', '2017-11-22 06:06:40'),
(34, 'APPMB', 'Onnet', 30, 0, 3, 0, 4, 0.35, 1.25, '2', '2017-11-22 06:06:02', '2017-11-22 06:06:40'),
(35, 'APPMB', 'Onnet', 30, 0, 3, 5, 9, 0.35, 1.25, '2', '2017-11-22 06:06:02', '2017-11-22 06:06:40'),
(36, 'APPMB', 'Onnet', 30, 0, 3, 10, 14, 0.35, 1.25, '2', '2017-11-22 06:06:02', '2017-11-22 06:06:40'),
(37, 'APPMB', 'Anynet', 1, 0, 3, 0, 4, 0.36, 1.26, '0', '2017-11-22 06:06:02', '2017-11-22 06:06:40'),
(38, 'APPMB', 'Anynet', 1, 0, 3, 5, 9, 0.36, 1.26, '0', '2017-11-22 06:06:02', '2017-11-22 06:06:40'),
(39, 'APPMB', 'Anynet', 1, 0, 3, 10, 14, 0.36, 1.26, '0', '2017-11-22 06:06:02', '2017-11-22 06:06:40'),
(40, 'APPMB', 'Anynet', 7, 0, 3, 0, 4, 0.35, 1.25, '1', '2017-11-22 06:06:40', '2017-11-22 06:06:40'),
(41, 'APPMB', 'Anynet', 7, 0, 3, 5, 9, 0.35, 1.25, '1', '2017-11-22 06:06:40', '2017-11-22 06:06:40'),
(42, 'APPMB', 'Anynet', 7, 0, 3, 10, 14, 0.35, 1.25, '1', '2017-11-22 06:06:40', '2017-11-22 06:06:40'),
(43, 'APPMB', 'Anynet', 15, 0, 3, 0, 4, 0.35, 1.25, '1', '2017-11-22 06:06:40', '2017-11-22 06:06:40'),
(44, 'APPMB', 'Anynet', 15, 0, 3, 5, 9, 0.35, 1.25, '1', '2017-11-22 06:06:40', '2017-11-22 06:06:40'),
(45, 'APPMB', 'Anynet', 15, 0, 3, 10, 14, 0.35, 1.25, '1', '2017-11-22 06:06:40', '2017-11-22 06:06:40'),
(46, 'APPMB', 'Anynet', 30, 0, 3, 0, 4, 0.35, 1.25, '1', '2017-11-22 06:06:40', '2017-11-22 06:06:40'),
(47, 'APPMB', 'Anynet', 30, 0, 3, 5, 9, 0.35, 1.25, '1', '2017-11-22 06:06:40', '2017-11-22 06:06:40'),
(48, 'APPMB', 'Anynet', 30, 0, 3, 10, 14, 0.35, 1.25, '1', '2017-11-22 06:06:40', '2017-11-22 06:06:40');

-- --------------------------------------------------------

--
-- Table structure for table `get_otps`
--

CREATE TABLE `get_otps` (
  `id` int(11) NOT NULL,
  `msisdn` varchar(15) NOT NULL,
  `pin` varchar(10) NOT NULL,
  `expiry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pin_status` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `get_otps`
--

INSERT INTO `get_otps` (`id`, `msisdn`, `pin`, `expiry_date`, `pin_status`, `created_at`, `updated_at`) VALUES
(1, '01744484535', '1955', '2017-11-21 10:48:55', 'Not Verified', '2017-11-21 09:48:55', '2017-11-21 09:48:55'),
(2, '01712252525', '8259', '2017-11-22 07:43:37', 'Not Verified', '2017-11-22 07:43:37', '2017-11-22 07:43:37'),
(3, '01712252525', '9798', '2017-11-22 08:44:09', 'Not Verified', '2017-11-22 07:44:09', '2017-11-22 07:44:09'),
(4, '01712252525', '1479', '2017-11-22 08:48:46', 'Not Verified', '2017-11-22 07:48:46', '2017-11-22 07:48:46'),
(5, '01712252525', '6997', '2017-11-22 08:56:34', 'Not Verified', '2017-11-22 07:56:34', '2017-11-22 07:56:34'),
(6, '01712252525', '9950', '2017-11-22 08:57:44', 'Not Verified', '2017-11-22 07:57:44', '2017-11-22 07:57:44'),
(7, '01712252525', '6008', '2017-11-22 08:58:06', 'Not Verified', '2017-11-22 07:58:06', '2017-11-22 07:58:06'),
(8, '01712252525', '4380', '2017-11-22 08:59:30', 'Not Verified', '2017-11-22 07:59:30', '2017-11-22 07:59:30'),
(9, '01712255555', '1086', '2017-11-23 07:21:42', 'Not Verified', '2017-11-23 06:21:42', '2017-11-23 06:21:42'),
(10, '01712255555', '7512', '2017-11-23 07:36:04', 'Not Verified', '2017-11-23 06:36:04', '2017-11-23 06:36:04'),
(11, '01712255555', '4094', '2017-11-23 07:43:51', 'Not Verified', '2017-11-23 06:43:51', '2017-11-23 06:43:51'),
(12, '01712255555', '4486', '2017-11-23 07:47:17', 'Not Verified', '2017-11-23 06:47:17', '2017-11-23 06:47:17'),
(13, '01712256666', '5336', '2017-11-23 07:48:45', 'Not Verified', '2017-11-23 06:48:45', '2017-11-23 06:48:45'),
(14, '01712252526', '7932', '2017-11-29 11:05:59', 'Not Verified', '2017-11-29 10:05:59', '2017-11-29 10:05:59'),
(15, '01770168222', '2755', '2017-11-29 11:10:07', 'Not Verified', '2017-11-29 10:10:07', '2017-11-29 10:10:07'),
(16, '01712337579', '0213', '2017-11-29 11:17:11', 'Not Verified', '2017-11-29 10:17:11', '2017-11-29 10:17:11'),
(17, '01712337579', '1620', '2017-11-29 11:18:02', 'Not Verified', '2017-11-29 10:18:02', '2017-11-29 10:18:02'),
(18, '01712337571', '2678', '2017-11-29 11:18:40', 'Not Verified', '2017-11-29 10:18:40', '2017-11-29 10:18:40'),
(19, '01712337571', '2928', '2017-11-29 11:18:51', 'Not Verified', '2017-11-29 10:18:51', '2017-11-29 10:18:51'),
(20, '01712337572', '6098', '2017-11-29 11:20:06', 'Not Verified', '2017-11-29 10:20:06', '2017-11-29 10:20:06'),
(21, '01712337572', '9589', '2017-11-29 11:20:35', 'Not Verified', '2017-11-29 10:20:35', '2017-11-29 10:20:35'),
(22, '01712337572', '8716', '2017-11-29 11:21:56', 'Not Verified', '2017-11-29 10:21:56', '2017-11-29 10:21:56'),
(23, '01712337572', '9492', '2017-11-29 11:22:44', 'Not Verified', '2017-11-29 10:22:44', '2017-11-29 10:22:44'),
(24, '01712337572', '6451', '2017-11-29 11:23:10', 'Not Verified', '2017-11-29 10:23:10', '2017-11-29 10:23:10'),
(25, '01712337573', '0246', '2017-11-29 11:23:39', 'Not Verified', '2017-11-29 10:23:39', '2017-11-29 10:23:39');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL,
  `customer_id` varchar(50) NOT NULL,
  `version_code` varchar(50) NOT NULL,
  `msisdn` varchar(15) NOT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `imei` varchar(50) DEFAULT NULL,
  `purchase_number` varchar(50) NOT NULL,
  `transaction_id` varchar(50) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `net_type` varchar(30) NOT NULL,
  `data` int(11) NOT NULL,
  `voice` int(11) NOT NULL,
  `validity` int(11) NOT NULL,
  `sms` int(11) NOT NULL,
  `flexi_plan_price` float NOT NULL,
  `discount` float NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`id`, `customer_id`, `version_code`, `msisdn`, `platform`, `imei`, `purchase_number`, `transaction_id`, `remarks`, `status`, `net_type`, `data`, `voice`, `validity`, `sms`, `flexi_plan_price`, `discount`, `created_at`, `updated_at`) VALUES
(1, '99', 'xx', '01770168228', '', '', 'FP00054', '0', 'Successfully forwarded', 'success', '', 50, 100, 30, 200, 40.25, 6.3, '2017-11-21 07:12:38', '2017-11-21 07:12:38'),
(2, '99', 'xx', '01770168228', '', '', 'FP00054', '0', 'Successfully forwarded', 'success', '', 50, 100, 30, 200, 40.25, 6.3, '2017-11-21 07:13:26', '2017-11-21 07:13:26'),
(3, '99', 'xx', '01770168228', '', '', 'FP00054', '0', 'Successfully forwarded', 'success', '', 50, 100, 30, 200, 40.25, 6.3, '2017-11-21 07:14:50', '2017-11-21 07:14:50'),
(4, '99', 'xx', '01770168228', '', '', 'FP00054', '0', 'Successfully forwarded', 'success', '', 50, 100, 30, 200, 40.25, 6.3, '2017-11-21 07:15:00', '2017-11-21 07:15:00'),
(5, '99', 'xx', '01770168228', '', '', 'FP00054', '0', 'Successfully forwarded', 'success', '', 50, 100, 30, 200, 40.25, 6.3, '2017-11-21 07:15:46', '2017-11-21 07:15:46'),
(6, '99', 'xx', '01770168228', '', '', 'FP00054', '0', 'Successfully forwarded', 'success', '', 50, 100, 30, 200, 40.25, 6.3, '2017-11-21 07:21:08', '2017-11-21 07:21:08'),
(7, '99', 'xx', '01770168228', '', '', 'FP00054', '0', 'Successfully forwarded', 'success', '', 50, 100, 30, 200, 40.25, 6.3, '2017-11-21 07:22:37', '2017-11-21 07:22:37'),
(8, '99', 'xx', '01770168228', '', '', 'FP00054', '0', 'Successfully forwarded', 'success', '', 50, 100, 30, 200, 40.25, 6.3, '2017-11-21 07:26:18', '2017-11-21 07:26:18'),
(9, '99', 'xx', '01770168228', '', '', 'FP00054', '0', 'Successfully forwarded', 'success', '', 50, 100, 30, 200, 40.25, 6.3, '2017-11-21 07:28:49', '2017-11-21 07:28:49'),
(10, '99', 'xx', '01712337579', '', '', 'FP00054', '0', 'Successfully forwarded', 'success', '', 100, 0, 15, 0, 20.55, 2.55, '2017-11-21 07:33:35', '2017-11-21 07:33:35'),
(11, '99', 'xx', '01712337579', '', '', 'FP00054', '0', 'Successfully forwarded', 'success', '', 100, 0, 15, 0, 20.55, 2.55, '2017-11-21 07:56:33', '2017-11-21 07:56:33'),
(12, '99', 'xx', '01712337579', 'ios', 'IME458745', 'FP00054', '0', 'Successfully forwarded', 'success', '', 100, 0, 15, 0, 20.55, 2.55, '2017-11-21 09:08:15', '2017-11-21 09:08:15'),
(13, '99', 'xx', '01712337579', 'ios', 'IME458745', 'FP00054', '0', 'Successfully forwarded', 'success', '', 100, 0, 15, 0, 20.55, 2.55, '2017-11-22 07:50:58', '2017-11-22 07:50:58'),
(14, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Other error', 'rejected', '', 100, 35, 30, 500, 45.85, 12.54, '2017-11-26 03:44:56', '2017-11-26 03:44:56'),
(15, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Insufficient balance', 'rejected', '', 100, 35, 30, 500, 45.85, 12.54, '2017-11-26 03:49:33', '2017-11-26 03:49:33'),
(16, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Insufficient balance', 'insufficient_balance', '', 100, 35, 30, 500, 45.85, 12.54, '2017-11-26 07:05:12', '2017-11-26 07:05:12'),
(17, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Insufficient balance', 'insufficient_balance', '', 100, 35, 30, 500, 45.85, 12.54, '2017-11-26 07:11:34', '2017-11-26 07:11:34'),
(18, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Insufficient balance', 'insufficient_balance', '', 100, 35, 30, 500, 45.85, 12.54, '2017-11-26 07:11:48', '2017-11-26 07:11:48'),
(19, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Insufficient balance', 'insufficient_balance', '', 100, 35, 30, 500, 45.85, 12.54, '2017-11-26 07:12:06', '2017-11-26 07:12:06'),
(20, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Successfully forwarded', 'success', '', 100, 35, 30, 500, 45.85, 12.54, '2017-11-26 07:12:18', '2017-11-26 07:12:18'),
(21, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Insufficient balance', 'insufficient_balance', '', 100, 35, 30, 500, 45.85, 12.54, '2017-11-26 07:12:26', '2017-11-26 07:12:26'),
(22, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Insufficient balance', 'insufficient_balance', '', 100, 35, 30, 500, 45.85, 12.54, '2017-11-26 07:50:41', '2017-11-26 07:50:41'),
(23, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Insufficient balance', 'insufficient_balance', 'anynet', 100, 35, 30, 500, 45.85, 12.54, '2017-11-30 04:53:16', '2017-11-30 04:53:16'),
(24, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Successfully forwarded', 'success', 'anynet', 100, 35, 30, 500, 45.85, 12.54, '2017-11-30 04:54:04', '2017-11-30 04:54:04'),
(25, '99', 'xx', '01744484535', 'ios', 'IME458745', 'FP00054', '0', 'Successfully forwarded', 'success', 'onnet', 100, 35, 30, 500, 45.85, 12.54, '2017-11-30 04:54:41', '2017-11-30 04:54:41');

-- --------------------------------------------------------

--
-- Table structure for table `recharge_urls`
--

CREATE TABLE `recharge_urls` (
  `id` int(11) NOT NULL,
  `recharge_url` varchar(255) NOT NULL,
  `msisdn` varchar(15) NOT NULL,
  `amount` float NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `title`, `status`, `created_at`, `updated_at`) VALUES
(1, 'administrator', 'Administrator', '1', '2017-12-11 04:52:34', '2017-12-11 04:52:34'),
(2, 'customer', 'Customer', '1', '2017-12-11 04:52:34', '2017-12-11 04:52:34');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `settings_group` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(255) NOT NULL,
  `value_options` varchar(255) DEFAULT NULL,
  `value` text NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `settings_group`, `title`, `name`, `type`, `value_options`, `value`, `status`, `created_at`, `updated_at`) VALUES
(1, 'General', 'Site Title', 'site_title', 'string', '', 'FlexiPlan', '1', '2017-10-30 10:23:19', '2017-11-30 04:53:59'),
(18, 'API Settings', '3G Login ', 'check_3g_login', 'options', 'a:2:{s:3:"yes";s:7:"Allowed";s:2:"no";s:11:"Not Allowed";}', 'yes', '1', '2017-11-26 04:30:33', '2017-11-30 04:53:59'),
(19, 'API Settings', 'Purchase For', 'purchase_for', 'options', 'a:2:{s:7:"success";s:22:"Purchased successfully";s:20:"insufficient_balance";s:20:"Insufficient balance";}', 'success', '1', '2017-11-26 06:46:25', '2017-11-30 04:53:59');

-- --------------------------------------------------------

--
-- Table structure for table `sms_prices`
--

CREATE TABLE `sms_prices` (
  `id` int(11) NOT NULL,
  `sms_count` int(11) NOT NULL,
  `price` float NOT NULL,
  `price_per_sms` float NOT NULL,
  `market_price` float NOT NULL,
  `market_price_per_sms` float NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sms_prices`
--

INSERT INTO `sms_prices` (`id`, `sms_count`, `price`, `price_per_sms`, `market_price`, `market_price_per_sms`, `status`, `created_at`, `updated_at`) VALUES
(1, 50, 2, 0.04, 5, 0.1, '1', '2017-11-06 09:00:27', '2017-11-06 09:00:27'),
(2, 200, 4, 0.02, 10, 0.05, '1', '2017-11-07 03:52:59', '2017-11-07 03:52:59'),
(3, 500, 10, 0.02, 25, 0.05, '1', '2017-11-07 03:53:20', '2017-11-07 03:53:20'),
(4, 0, 0, 0, 0, 0, '1', '2017-11-07 08:37:51', '2017-11-07 08:37:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `rid` int(11) DEFAULT NULL,
  `nick` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `rid`, `nick`, `name`, `email`, `phone`, `password`, `created_at`, `updated_at`) VALUES
(4, 1, 'Kafi', 'M U Kafi', 'kafi@ergo-ventures.com', 8801770168228, '$2y$10$c.jUVt6UAl3cBVyxeLxQ8Od.RxYWEain3ji0nBM.m0Rfvb8qJ0/OO', '2017-11-08 06:32:06', '2017-12-11 05:23:02'),
(5, 1, 'Faiyaz', 'Faiyaz Moorsalin', 'faiyaz@ergo-ventures.com', 215487451, '$2y$10$rGxpa2iByV0hFrhWLpcIV.n8NnQ3ARxglj4I5w3BLVJBLRU8diRPu', '2017-12-11 05:51:53', '2017-12-11 06:39:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flexiplanOptions`
--
ALTER TABLE `flexiplanOptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flexiplans`
--
ALTER TABLE `flexiplans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `get_otps`
--
ALTER TABLE `get_otps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recharge_urls`
--
ALTER TABLE `recharge_urls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sms_prices`
--
ALTER TABLE `sms_prices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `flexiplanOptions`
--
ALTER TABLE `flexiplanOptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `flexiplans`
--
ALTER TABLE `flexiplans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `get_otps`
--
ALTER TABLE `get_otps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `recharge_urls`
--
ALTER TABLE `recharge_urls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `sms_prices`
--
ALTER TABLE `sms_prices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
